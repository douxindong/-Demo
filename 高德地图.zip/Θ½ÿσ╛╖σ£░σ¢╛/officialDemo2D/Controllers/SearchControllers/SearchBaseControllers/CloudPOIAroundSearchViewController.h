//
//  CloudPlaceAroundSearchViewController.h
//  AMapCloudDemo
//
//  Created by 刘博 on 14-3-11.
//  Copyright (c) 2014年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface CloudPOIAroundSearchViewController : BaseMapViewController

@end
