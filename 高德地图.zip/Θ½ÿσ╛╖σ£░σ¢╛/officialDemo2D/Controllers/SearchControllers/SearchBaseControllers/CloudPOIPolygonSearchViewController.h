//
//  CloudPlacePolygonSearchViewController.h
//  AMapCloudDemo
//
//  Created by 刘博 on 14-3-14.
//  Copyright (c) 2014年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface CloudPOIPolygonSearchViewController : BaseMapViewController

@end
