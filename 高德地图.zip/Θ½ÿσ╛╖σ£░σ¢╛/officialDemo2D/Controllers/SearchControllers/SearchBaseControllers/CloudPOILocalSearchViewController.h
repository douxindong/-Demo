//
//  CloudPlaceLocalSearchViewController.h
//  officialDemoCloud
//
//  Created by LiuX on 14-9-11.
//  Copyright (c) 2014年 AutoNavi. All rights reserved.
//

#import "BaseMapViewController.h"

@interface CloudPOILocalSearchViewController : BaseMapViewController

@end
