//
//  SubPoiDetailViewController.h
//  officialDemo2D
//
//  Created by KuangYe on 15/12/17.
//  Copyright © 2015年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapCommonObj.h>

@interface SubPoiDetailViewController : UIViewController

@property (nonatomic, strong) AMapSubPOI *subPoi;

@end
