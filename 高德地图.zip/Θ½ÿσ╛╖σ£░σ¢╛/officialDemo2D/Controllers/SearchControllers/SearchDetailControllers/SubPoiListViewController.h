//
//  SubPoiListViewController.h
//  officialDemo2D
//
//  Created by KuangYe on 15/12/17.
//  Copyright © 2015年 AutoNavi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubPoiListViewController : UIViewController

@property (nonatomic, strong) NSArray *subPois;

@end
